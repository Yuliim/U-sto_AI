import os
import pandas as pd
import numpy as np
from faker import Faker
import random
from datetime import datetime, timedelta
# ---------------------------------------------------------
# 0. 설정 및 초기화
# ---------------------------------------------------------
fake = Faker('ko_KR')  # 한국어 더미 데이터 생성기
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAVE_DIR = os.path.join(BASE_DIR, "data_lifecycle")
os.makedirs(SAVE_DIR, exist_ok=True) # 폴더가 없으면 생성

TOTAL_COUNT = 1000    # 생성할 데이터 개수 (1000건)

# 승인 상태 비율 설정 (확정 97%, 대기 2%, 반려 1%)
APPROVAL_RATIOS = [0.97, 0.02, 0.01]
APPROVAL_STATUSES = ['확정', '대기', '반려']
REMARK_TEMPLATES_BY_CLASS = {
    # IT / 전산 장비
    "노트북컴퓨터": [
        "AI 실습 수업용 노트북",
        "전산 실습실 공용 장비",
        "교수·연구원 업무용",
        "학과 공용 전산 자산"
    ],
    "데스크톱컴퓨터": [
        "전산 실습실 고정형 PC",
        "연구실 분석 업무용",
        "행정 업무용 데스크톱"
    ],
    "액정모니터": [
        "전산 실습실 보조 모니터",
        "사무환경 개선용",
        "연구실 다중 화면 구성용"
    ],
    "허브": [
        "전산망 확충용",
        "실습실 네트워크 구성용"
    ],
    "라우터": [
        "실습실 네트워크 증설",
        "학과 전산망 고도화"
    ],
    "하드디스크드라이브": [
        "연구 데이터 저장용",
        "서버 증설용 스토리지"
    ],
    "플래시메모리저장장치": [
        "교육 자료 배포용",
        "백업 매체"
    ],
    "스캐너": [
        "행정 문서 전산화",
        "자료 디지털 아카이빙"
    ],
    "레이저프린터": [
        "행정 문서 출력용",
        "학과 공용 프린터"
    ],

    # 가구 / 집기
    "책상": [
        "강의실 환경 개선",
        "연구실 집기 교체",
        "신규 연구실 구축"
    ],
    "작업용의자": [
        "사무환경 개선",
        "노후 집기 교체"
    ],
    "책걸상": [
        "강의실 집기 교체",
        "노후 책걸상 교체"
    ],
    "서랍형수납장": [
        "연구실 문서 보관용",
        "행정 자료 수납용"
    ],

    # 교육 기자재
    "칠판보조장": [
        "강의실 기자재 보강",
        "노후 기자재 교체"
    ],
    "인터랙티브화이트보드": [
        "스마트 강의실 구축",
        "디지털 강의 환경 개선"
    ],
}

# ---------------------------------------------------------
# 1. 마스터 데이터 정의 (Master Data)
# ---------------------------------------------------------
# 1-1. G2B 품목 마스터 (17개 표준 품목)
# 구조: [물품분류코드(8), 물품식별코드(8), 품목명, 분류명, 내용연수, 평균단가(원)]
# 캠퍼스 설정
CAMPUS_TYPES = ['서울', 'ERICA']
CAMPUS_PROBS = [0.5, 0.5] # 5:5 비율

G2B_MASTER_DATA = [
    # =========================
    # 전자·정보·통신·영상 (10)
    # =========================
    ("43211503", "24343967",  
     "노트북컴퓨터", # 품목명
     "노트북컴퓨터, Dell, (CN)Latitude 3520-5110H, Intel Core i5 1135G7(2.4GHz), 액세서리별도", # 분류명
     6,  # 내용연수 = 노트북 관행 값
     1133000),  # 평균단가 = 계약단가 평균

    ("43211503", "24510198", # 노트북
     "노트북컴퓨터",
     "노트북컴퓨터, Lenovo, (CN)82JBS00300, Intel Celeron N5100(1.1GHz), 액세서리별도", 
     6,  
     555000),  

    ("43211507", "24355228",  # 데스크톱
     "데스크톱컴퓨터",
     "데스크톱컴퓨터, Dell, (CN)OptiPlex 5090, Intel Core i5 10505(3.1GHz)",
     5,
     2627000),

    ("43211507", "24158946",  # 데스크톱
     "데스크톱컴퓨터",
     "데스크톱컴퓨터, 서버앤컴퓨터, DECA-N3802, Intel Core i3 10100(3.6GHz)",
     5,
     546000),

    ("43211902", "24407366",  # 모니터
     "LCD패널또는모니터",
     "액정모니터, 엘지전자, 27MP500W, 68.6cm",
     5,
     513000),

    ("43212105", "23858386",  # 레이저프린터
     "레이저프린터",
     "레이저프린터, HP, (JP)HP Color LaserJet Enterprise M856dn, A3/컬러56/흑백56ppm",
     6,
     3465000),

    ("43211711", "24204348",  # 스캐너
     "스캐너",
     "스캐너, Kodak alaris, (CN)S3100F, 600dpi",
     6,
     5500000),

    ("43222609", "23908131",  # 라우터
     "네트워크라우터",
     "43222609 네트워크라우터",
     9,
     542000),

    ("43201803", "23809899",  # HDD
     "하드디스크드라이브",
     "하드디스크드라이브, Hitachi vantara, (US)R2H-H10RSS, 10TB",
     7,
     5340000),

    ("43223308", "22060848",  # 네트워크 랙
     "네트워크시스템장비용랙",
     "네트워크시스템장비용랙, 600×2000×750mm",
     10,
     891700),
    # =========================
    # 사무·교육·가구 (5)
    # =========================
    ("56101703", "25114372",  # 책상
     "책상",
     "책상, 우드림, WD-WIZDE100, 2700×2150×750mm, 1인용",
     9,
     6000000),

    ("56112102", "24128496",  # 작업용의자
     "작업용의자",
     "작업용의자, 오피스안건사, AC-051, 513×520×783mm",
     8,
     93000),

    ("56112108", "24917370",  # 책걸상(콤비의자)
     "책상용콤비의자",
     "책걸상, 애니체, AMD-WT100A, 617×790×850mm",
     10,
     465000),

    ("56121798", "25616834",  # 칠판보조장
     "칠판보조장",
     "칠판보조장, 우드림, WR-BSC7040, 7000×300×3000mm",
     7,
     10500000),

    ("44111911", "25460962",  # 인터랙티브화이트보드
     "인터랙티브화이트보드및액세서리",
     "인터랙티브화이트보드, 미래디스플레이, MDI86110, 279.4cm, IR센서/손/도구/LED",
     7,
     24200000),
]
# [NEW] 특수 목적 물품 (별도 로직 적용)
# 일반 확률 분포를 따르지 않고, 특정 부서에만 고정 수량 배정
SPECIAL_ITEM_SERVER = ("43232902", "25461942", 
     "통신서버소프트웨어", 
     "통신소프트웨어, 세인트로그, SMART-CM V1.5, 통합방송솔루션, 1~4Core(Server)",
     6, 60000000)
# 1-2. 부서 마스터 (조직도)
DEPT_MASTER_DATA = [
    ("C354", "소프트웨어융합대학RC행정팀(ERICA)"),
    ("C352", "공학대학RC행정팀(ERICA)"),
    ("C364", "경상대학RC행정팀(ERICA)"),
    ("C360", "글로벌문화통상대학RC행정팀(ERICA)"),
    ("A351", "시설팀(ERICA)"),
    ("A320", "학생지원팀(ERICA)"),
]
# ---------------------------------------------------------
# [수정] 현실 기반 확률 분포 설정 (Items & Departments)
# ---------------------------------------------------------

# 1. 전체 물품 중 해당 물품이 선택될 확률 (총 15개 항목)
ITEM_WEIGHTS = [
    # =========================
    # IT / 전산 장비 (72%)
    # =========================
    0.135,  # 노트북 (고급형) - 기존 0.160 -> 0.135
    0.105,  # 노트북 (보급형) - 기존 0.130 -> 0.105
    0.115,  # 데스크톱 (고급형) - 기존 0.140 -> 0.115
    0.085,  # 데스크톱 (보급형) - 기존 0.110 -> 0.085
    0.120,  # 모니터
    0.055,  # 레이저프린터
    0.030,  # 스캐너
    0.020,  # 네트워크라우터
    0.020,  # HDD
    0.015,  # 네트워크랙

    # =========================
    # 사무·교육·가구 (28%)
    # =========================
    0.070,  # 책상
    0.090,  # 작업용의자
    0.055,  # 책걸상
    0.040,  # 칠판보조장
    0.045,  # 인터랙티브화이트보드
]
# ITEM_WEIGHTS 합계 검증 로직 추가
_item_weights_sum = sum(ITEM_WEIGHTS)
if abs(_item_weights_sum - 1.0) >= 0.001:
    raise ValueError(f"ITEM_WEIGHTS sum is {_item_weights_sum}, must be 1.0")
# 2. 각 물품별 부서 구매 비율 (인덱스: G2B_MASTER_DATA의 인덱스)
# 부서 순서: [C354(소프트), C352(공학), C364(경상), C360(글로벌), A351(시설), A320(학생)]
DEPT_WEIGHTS_BY_ITEM = {
    # === IT / 전산 장비 ===
    0: [0.18, 0.20, 0.10, 0.07, 0.10, 0.35], # 노트북
    1: [0.18, 0.20, 0.10, 0.07, 0.10, 0.35], # 노트북
    2: [0.20, 0.22, 0.08, 0.05, 0.15, 0.30], # 데스크톱
    3: [0.20, 0.22, 0.08, 0.05, 0.15, 0.30], # 데스크톱
    4: [0.17, 0.20, 0.09, 0.07, 0.12, 0.35], # 모니터
    5: [0.14, 0.12, 0.08, 0.06, 0.15, 0.45], # 레이저프린터
    6: [0.12, 0.10, 0.08, 0.05, 0.20, 0.45], # 스캐너
    7: [0.03, 0.04, 0.01, 0.01, 0.85, 0.06], # 라우터
    8: [0.02, 0.03, 0.01, 0.01, 0.88, 0.05], # HDD
    9: [0.00, 0.01, 0.00, 0.00, 0.95, 0.04], # 랙 (2000mm)

    
    # === 사무 / 가구 ===
    10: [0.18, 0.20, 0.15, 0.12, 0.20, 0.15], # 책상
    11: [0.20, 0.22, 0.15, 0.13, 0.15, 0.15], # 작업용의자
    12: [0.18, 0.30, 0.20, 0.22, 0.05, 0.05], # 책걸상
    13: [0.20, 0.30, 0.25, 0.15, 0.08, 0.02], # 칠판보조장
    14: [0.22, 0.32, 0.20, 0.14, 0.10, 0.02], # 화이트보드
}
def _validate_dept_weights_by_item():
    """
    Validate that DEPT_WEIGHTS_BY_ITEM has the expected structure:
    - All item indices from 0 to 14 are present.
    - Each item has exactly 6 department weights.
    - Each set of weights sums to 1.0 (within a small numerical tolerance).
    """
    expected_num_items = 15
    expected_num_depts = 6
    missing_indices = [i for i in range(expected_num_items) if i not in DEPT_WEIGHTS_BY_ITEM]
    if missing_indices:
        raise ValueError(
            f"DEPT_WEIGHTS_BY_ITEM is missing definitions for item indices: {missing_indices}"
        )
    for item_idx, weights in DEPT_WEIGHTS_BY_ITEM.items():
        if len(weights) != expected_num_depts:
            raise ValueError(
                f"DEPT_WEIGHTS_BY_ITEM[{item_idx}] has {len(weights)} weights; "
                f"expected {expected_num_depts}."
            )
        total_weight = sum(weights)
        if not np.isclose(total_weight, 1.0, atol=1e-6):
            raise ValueError(
                f"DEPT_WEIGHTS_BY_ITEM[{item_idx}] weights sum to {total_weight:.10f}; "
                "expected sum of 1.0."
            )
_validate_dept_weights_by_item()
# ---------------------------------------------------------
# 2. 데이터 생성 로직 (Phase 1)
# ---------------------------------------------------------
# ---------------------------------------------------------
# 1. 데이터 생성 함수 정의
# ---------------------------------------------------------
def generate_acquisition_data(count):
    print(f"🚀 [Phase 1] 물품 취득 데이터 {count}건 생성을 시작합니다...")
    
    acquisition_list = []
    
    # 기준일자 설정
    now = datetime.now()
    today = datetime(now.year, now.month, now.day)
    
    # 물품 인덱스 리스트 (0 ~ len(G2B_MASTER_DATA)-1)
    item_indices = range(len(G2B_MASTER_DATA))

    for _ in range(count):
        # -------------------------------------------------
        # 1) 기본 정보 선택 (가중치 적용)
        # -------------------------------------------------
        # 물품 선정
        selected_idx = random.choices(item_indices, weights=ITEM_WEIGHTS, k=1)[0]
        g2b_item = G2B_MASTER_DATA[selected_idx]
        
        # 부서 선정 (물품별 가중치 적용)
        dept_weights = DEPT_WEIGHTS_BY_ITEM[selected_idx]
        dept = random.choices(DEPT_MASTER_DATA, weights=dept_weights, k=1)[0]
        
        # G2B 정보 언패킹
        class_code, id_code, item_name, class_name, life_years, base_price = g2b_item
        g2b_full_code = class_code + id_code # 16자리 목록번호
        
        # -------------------------------------------------
        # 2) 승인 상태 결정 (확정/대기/반려)
        # -------------------------------------------------
        approval_status = np.random.choice(APPROVAL_STATUSES, p=APPROVAL_RATIOS)
        
        # -------------------------------------------------
        # 3) 날짜 생성 로직 (디테일 유지)
        # -------------------------------------------------
        start_date_range = datetime(2015, 1, 1)
        
        # '대기' 상태는 최근(2024년 10월 이후)에 몰려있도록 설정
        if approval_status == '대기':
            wait_start = datetime(2024, 10, 1)
            # wait_start가 today보다 미래인 경우 방지
            if wait_start > today: wait_start = today
            temp_date = fake.date_between(start_date=wait_start, end_date=today)
        else:
            temp_date = fake.date_between(start_date=start_date_range, end_date=today)
        
        # datetime 객체 변환
        acq_date = datetime(temp_date.year, temp_date.month, temp_date.day)

        # 캠퍼스 랜덤 배정
        campus = np.random.choice(CAMPUS_TYPES, p=CAMPUS_PROBS)
        
        # -------------------------------------------------
        # 4) 정리일자 생성
        # -------------------------------------------------
        clear_date = None
        if approval_status == '확정':
            random_days = random.randint(3, 14)
            clear_date = (acq_date + timedelta(days=random_days))
            # 정리일자는 현재 날짜를 초과하지 않도록 제한
            if clear_date > today:
                clear_date = today
                
        # -------------------------------------------------
        # 5) 수량 및 금액 생성 (품목별 차이 반영)
        # -------------------------------------------------
        # 책상/의자류는 대량 구매 가능성 높음
        if "책상" in item_name or "의자" in item_name:
            # 의자/책상: 1~5개(소규모) vs 10~50개(강의실) 혼합 분포
            quantity = random.choices([random.randint(1, 5), random.randint(10, 50)], weights=[0.7, 0.3])[0]
        elif "PC" in item_name or "노트북" in item_name:
             # PC류: 1~5대(개인/연구실) vs 20~40대(실습실)
            quantity = random.choices([random.randint(1, 5), random.randint(20, 40)], weights=[0.85, 0.15])[0]
        else:
            # 기타 장비: 소량
            quantity = random.randint(1, 5)
            
        # 취득금액 = (단가 * 수량) + 랜덤 노이즈(옵션가 등 ±10%)
        unit_price = int(base_price * random.uniform(0.9, 1.1)) 
        total_amount = unit_price * quantity
        total_amount = (total_amount // 1000) * 1000 # 1000원 단위 절삭
        
        # -------------------------------------------------
        # 6) 기타 속성 (취득정리구분, 비고)
        # -------------------------------------------------
        acq_method = np.random.choice(['자체구입', '자체제작', '기증'], p=[0.95, 0.02, 0.03])
        
        remark = ""
        if approval_status == '반려':
            remark = "예산 초과로 인한 반려"
        elif random.random() < 0.1: # 10% 확률로 비고 생성
            # 기존 split(' ')[1] 방식 제거하고 안전한 매핑 로직 적용
            try:
                # 우선순위 1: item_name 그대로 사용 ("노트북컴퓨터")
                key_candidate = item_name
                
                # 매핑되지 않으면 콤마로 분리 시도 (혹시 class_name에 브랜드 등이 섞인 경우)
                if key_candidate not in REMARK_TEMPLATES_BY_CLASS:
                    # 예: "노트북컴퓨터, LG전자" -> "노트북컴퓨터"
                    key_candidate = str(item_name).split(',')[0].strip()

            except (IndexError, AttributeError):
                key_candidate = item_name

            candidates = REMARK_TEMPLATES_BY_CLASS.get(key_candidate, [])
            # 매핑 실패 시 포괄적인 키워드로 재시도 (예: 컴퓨터 -> 데스크톱)
            if not candidates:
                if "컴퓨터" in item_name: candidates = REMARK_TEMPLATES_BY_CLASS.get("데스크톱컴퓨터", [])
                elif "의자" in item_name: candidates = REMARK_TEMPLATES_BY_CLASS.get("작업용의자", [])
            
            if candidates:
                remark = random.choice(candidates)

        # 문자열 변환
        acq_date_str = acq_date.strftime('%Y-%m-%d')
        clear_date_str = clear_date.strftime('%Y-%m-%d') if clear_date else ""

        # -------------------------------------------------
        # 7) 데이터 적재
        # -------------------------------------------------
        row = {
            # 식별 정보
            'G2B_목록번호': g2b_full_code,
            'G2B_목록명': item_name,
            # G2B 상세 (조회용)
            '물품분류코드': class_code,
            '물품분류명': class_name,
            '물품식별코드': id_code,
            '물품품목명': item_name, 
            '캠퍼스': campus,  
            
            # 취득 정보
            '취득일자': acq_date_str,
            '취득금액': total_amount,
            '정리일자': clear_date_str,
            '취득정리구분': acq_method,
            
            # 관리 정보
            '운용부서': dept[1],
            '운용부서코드': dept[0],
            '운용상태': '취득',
            '내용연수': life_years,
            '수량': quantity,
            '승인상태': approval_status,
            '비고': remark
        }
        acquisition_list.append(row)
        # ---------------------------------------------------------
    # [NEW] 특수 물품(서버) 추가 로직 (Probability Injection)
    # ---------------------------------------------------------
    print("⚡ [Phase 1] 특수 물품(통신서버소프트웨어) 데이터를 주입합니다...")
    
    # 1) 서버 데이터 언패킹
    sv_class_code, sv_id_code, sv_item_name, sv_class_name, sv_life, sv_price = SPECIAL_ITEM_SERVER
    sv_full_code = sv_class_code + sv_id_code

    # 2) 부서별 할당 시나리오 정의
    # (부서코드, 부서명, 최소수량, 최대수량)
    server_allocations = [
        ("A351", "시설팀(ERICA)", 2, 3),      # 시설팀: 2~3대 (구축+교체)
        ("A320", "학생지원팀(ERICA)", 1, 2),  # 학생팀: 1~2대
        # RC 행정팀은 리스트에 없으므로 자동 0건 처리됨
    ]

    for dept_code, dept_name, min_cnt, max_cnt in server_allocations:
        # 할당 수량 결정
        target_qty = random.randint(min_cnt, max_cnt)
        
        for i in range(target_qty):
            # 날짜 생성 로직 (2015년 ~ 현재 사이)
            # 수량이 여러 개일 경우, 초기 구축(과거)과 교체(최근) 느낌을 주기 위해 날짜 분산
            if i == 0: 
                # 첫 번째는 좀 더 과거 (2015 ~ 2019)
                start_d = datetime(2015, 1, 1)
                end_d = datetime(2019, 12, 31)
            else:
                # 두 번째 이후는 좀 더 최근 (2020 ~ 현재)
                start_d = datetime(2020, 1, 1)
                end_d = today
            
            # 범위 내 랜덤 날짜
            temp_date = fake.date_between(start_date=start_d, end_date=end_d)
            if temp_date > today.date(): temp_date = today.date() # 미래 방지
            acq_date = datetime(temp_date.year, temp_date.month, temp_date.day)

            # 정리일자 (확정 전제)
            clear_date = acq_date + timedelta(days=random.randint(7, 30)) # 서버는 도입 기간이 좀 더 김
            if clear_date > today: clear_date = today

            # 데이터 생성
            row = {
                'G2B_목록번호': sv_full_code,
                'G2B_목록명': sv_item_name,
                '물품분류코드': sv_class_code,
                '물품분류명': sv_class_name,
                '물품식별코드': sv_id_code,
                '물품품목명': sv_item_name,
                '캠퍼스': 'ERICA', # 서버는 주로 캠퍼스 단위 관리이므로 ERICA 고정 (혹은 랜덤)
                
                '취득일자': acq_date.strftime('%Y-%m-%d'),
                '취득금액': sv_price, # 6천만원 고정
                '정리일자': clear_date.strftime('%Y-%m-%d'),
                '취득정리구분': '자체구입', # 서버는 주로 구입
                
                '운용부서': dept_name,
                '운용부서코드': dept_code,
                '운용상태': '취득',
                '내용연수': sv_life,
                '수량': 1, # 서버는 대당 가격이 높으므로 1대씩 등록
                '승인상태': '확정', # 고가 장비는 이미 확정된 건만 넘어오는 경우가 많음
                '비고': f"{dept_name} 서버실 운용"
            }
            acquisition_list.append(row)

    # ---------------------------------------------------------
    # [NEW] 로직 끝
    # ---------------------------------------------------------
        
    # DataFrame 변환
    df_acquisition = pd.DataFrame(acquisition_list)
    return df_acquisition
# ---------------------------------------------------------
# 3. 결과 저장 (CSV Export)
# ---------------------------------------------------------

# 함수 호출하여 데이터프레임 생성
df_acquisition = generate_acquisition_data(TOTAL_COUNT)

# [03-01] 물품 취득 대장 목록 (Main Output)
# 필요한 컬럼만 추출하여 저장
cols_acquisition = [
    'G2B_목록번호', 'G2B_목록명', '캠퍼스', '취득일자', '취득금액', '정리일자', 
    '운용부서', '운용상태', '내용연수', '수량', '승인상태', 
    '취득정리구분', '운용부서코드', '비고'
]
df_acquisition[cols_acquisition].to_csv(os.path.join(SAVE_DIR, '03_01_acquisition_master.csv'), index=False, encoding='utf-8-sig')

# [03-02] G2B 목록 조회용 (Popup Output)
# 분류 목록 (중복 제거)
df_class = df_acquisition[['물품분류코드', '물품분류명']].drop_duplicates()
df_class.to_csv(os.path.join(SAVE_DIR, '03_02_g2b_class_list.csv'), index=False, encoding='utf-8-sig')

# 품목 목록 (중복 제거)
df_item = df_acquisition[['물품식별코드', '물품품목명', '물품분류코드']].drop_duplicates()
df_item.to_csv(os.path.join(SAVE_DIR, '03_02_g2b_item_list.csv'), index=False, encoding='utf-8-sig')

print("✅ [Phase 1] 데이터 생성 완료!")
print(f"   - 총 {len(df_acquisition)}건의 취득 데이터가 생성되었습니다.")
print("   - 저장 파일: 03_01_acquisition_master.csv, 03_02_g2b_class_list.csv, 03_02_g2b_item_list.csv")
print("   - 승인 상태 분포:")
print(df_acquisition['승인상태'].value_counts())